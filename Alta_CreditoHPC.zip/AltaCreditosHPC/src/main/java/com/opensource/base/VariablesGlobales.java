package com.opensource.base;

public class VariablesGlobales {
	// indicar el driver a usar
	public static final String KEY_CHROME_DRIVER="webdriver.chrome.driver";	
	// ingresar la ruta del driver
	public static final String PATH_CHROME_DRIVER ="./src/main/resources/Driver/chromedriver.exe";
	// ruta de ingreso
	public static final String SDA_URL = "http://intranetib/sda/";
	public static final int GENERAL_TIMEOUT =30;
	public static final int GENERAL_IMPLICIT_TIMEOUT = 0;
	public static final String PATH_JSON_DATA = "./src/test/resources/json/";
}	

