package com.opensource.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.opensource.base.Base;

public class UserManagement extends Base {

	By txtusuario =By.id("inpuser");
	By txtpassword =By.id("inp_clave");
	By opcAmbiente =By.xpath("//option[contains(text(),'Pruebas')]");

	public UserManagement(WebDriver driver) {
	super(driver);
		}

	public void login(String usuario, String pwd) throws InterruptedException {
		reporter("login..."+usuario);
		type(txtusuario,usuario);
		Thread.sleep(2000);
		type(txtpassword,pwd);
		Thread.sleep(2000);
		click(opcAmbiente);
		
		implicitWait();
	}



}

