package com.opensource.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.opensource.base.Base;

public class Login extends Base {

	By txtuse =By.id("txtuser");
	By txtpwd =By.id("inp_clave");
	By opcUAT =By.xpath("//option[contains(text(),'Pruebas')]");
	By welcome =By.xpath("//p[contains(text(),'Bienvenido')]");

	public Login(WebDriver driver) {
	super(driver);
}

	
	public void loginuat(String username, String pwd, boolean isLogged) {
		reporter("Login UAT");
		type(txtuse, username);
		type(txtpwd, pwd);
		click(opcUAT);
		if(isLogged) {
			waitForElementPresent(welcome);
		}
	}
	
	public void loginuat(String username, String pwd) {
		loginuat(username, pwd, true);
	}
		
		
	
}